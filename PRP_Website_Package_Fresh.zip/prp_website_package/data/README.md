# Data folder

No polling or election datasets are included in this prototype.

Before adding records, document each source and confirm its reuse terms. Never invent missing polls or results. Recommended fields are listed in the main README.

A future implementation can store normalized records in JSON or CSV and load them into the site, or connect to a database/API. Keep source metadata with every observation.
